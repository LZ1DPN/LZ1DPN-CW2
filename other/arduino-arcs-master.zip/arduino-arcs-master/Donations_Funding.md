
# About donations and founding #

No payment of whatsoever is required to use this code: this is [Free/Libre Software](https://en.wikipedia.org/wiki/Software_Libre), nevertheless donations and funding are very welcomed.

I live in the Cuba island and the Internet is very expensive here; you can help me stay connected by fund me or simply donate the cost of a beer/coffee if you like to do so, of course more than one is allowed ;-)

If you like to contribute in this way please contact the author at pavelmc@gmail.com for instructions on how to do it.

Thanks before hand.
